// array untuk menyimpan data buku
const books = [];

module.exports = books;
